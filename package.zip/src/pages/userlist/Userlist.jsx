import React, { useEffect, useState } from 'react'
import './Userlist.css'
import BottomNav from '../../components/bottommenu/BottomNav'
import Navbar from '../../components/navbar/Navbar'
import { deleteUser, getUsers } from '../../action/user';
import { Link } from 'react-router-dom';

function Userlist() {


  const [userData,setUserData]=useState(null);

  useEffect(() => {

    loadusers();
   
  }, []);

  const loadusers=async()=>{
    const result=await getUsers();
    setUserData(result.data);
   }


   const DeleteUser=async(userID)=>{


    const res = await deleteUser(userID);
    console.log(res);
    const { responseStatus, outputMessage } = res.data.output;
    if (responseStatus === "failed") {
      console.log("exception:", outputMessage);
    }
  
    console.log("successful:", outputMessage);
  }


  return (
    <>
    <Navbar/>
    <div className="body">
      <div className= "rounded p-2 ">
        <h2 className='d-flex justify-content-center align-items-center'>User List</h2>
        <div className="d-flex justify-content-end">
          <Link to="/userregister/0/I" className="btn btn-info">Add User</Link>
        </div>
        <table className="table1 table rounded">
          <thead>
            <tr>
              <th>User Name</th>
              <th>Display Name</th>
              <th>Password</th>
              <th>Mobile</th>
              <th>Tel</th>
              <th>Address</th>
              <th>Email</th>
              <th>Billing Address</th>
              <th>Edit|Delete</th>
            </tr>
          </thead>
          <tbody>
            
            {/* {JSON.stringify(userData)} */}
            {userData && userData.map((user) => (
                  <tr key={user.userID}>
                    <td>{user.userName}</td>
                    <td>{user.displayName}</td>
                    <td>{user.password}</td>
                    <td>{user.mobileNo}</td>
                    <td>{user.tel}</td>
                    <td>{user.siteAddress}</td>
                    <td>{user.email}</td>
                    <td>{user.billingAddress}</td>
                    <td>
                      <Link to={`/userregister/${user.userID}/U`} className="btn btn-sm btn-primary">Edit</Link>&nbsp;
                      <button className="btn btn-sm btn-danger" onClick={() => DeleteUser(user.userID)}>Delete</button>
                    </td>
                  </tr>
                ))}
          </tbody>
        </table>
      </div>
  </div>
  <BottomNav className="bottombar"/>
    </>
  )
}

export default Userlist

//   const [data, setData] = useState([]);
//   useEffect(() => {
//     axios.get('http://localhost:8000/')
//       .then(res => setData(res.data))
//       .catch(err => console.log(err));
//   }, [])